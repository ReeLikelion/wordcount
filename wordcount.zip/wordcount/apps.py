from django.apps import AppConfig


class WordcountConfig(AppConfig):
    name = 'wordcount'
